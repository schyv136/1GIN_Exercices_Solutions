public class Hashtable extends Dictionary implements Map
{
}