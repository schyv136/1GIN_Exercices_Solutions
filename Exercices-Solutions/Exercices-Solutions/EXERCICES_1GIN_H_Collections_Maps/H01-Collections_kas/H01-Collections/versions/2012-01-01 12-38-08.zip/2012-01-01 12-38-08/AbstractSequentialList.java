public abstract class AbstractSequentialList extends AbstractList
{
}