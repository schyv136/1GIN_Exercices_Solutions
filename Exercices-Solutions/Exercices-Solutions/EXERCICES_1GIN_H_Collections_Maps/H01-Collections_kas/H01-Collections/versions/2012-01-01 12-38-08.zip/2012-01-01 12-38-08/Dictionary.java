public abstract class Dictionary
{
}