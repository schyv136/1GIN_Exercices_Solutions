public interface Iterable<E> 
{
}