public abstract class AbstractList<E> extends AbstractCollection<E> implements List<E> 
{
}