public abstract class AbstractSet extends AbstractCollection implements Set
{
}