/**
 * Write a description of class "AbstractList" here.
 * 
 * @author     fred
 * @version    01/01/2012 12:15:19
 */
public abstract class AbstractList extends AbstractCollection implements List
{
}