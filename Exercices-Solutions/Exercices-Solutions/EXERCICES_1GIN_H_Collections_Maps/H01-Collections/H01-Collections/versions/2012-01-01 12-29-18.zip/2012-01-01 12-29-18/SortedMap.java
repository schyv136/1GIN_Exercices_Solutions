public interface SortedMap extends Map
{
}