public interface NavigableMap extends SortedMap
{
}