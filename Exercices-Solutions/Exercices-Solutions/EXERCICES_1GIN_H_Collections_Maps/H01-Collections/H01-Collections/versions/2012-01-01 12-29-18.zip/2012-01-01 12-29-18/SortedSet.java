public interface SortedSet extends Set
{
}