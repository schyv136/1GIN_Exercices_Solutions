public class HashMap extends AbstractMap implements Map
{
}