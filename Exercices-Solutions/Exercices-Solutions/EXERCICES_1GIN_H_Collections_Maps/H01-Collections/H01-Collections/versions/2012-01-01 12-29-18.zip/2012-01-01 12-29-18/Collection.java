public interface Collection extends Iterable
{
}