/**
 * Write a description of class "AbstractCollection" here.
 * 
 * @author     fred
 * @version    01/01/2012 12:13:06
 */
public abstract class AbstractCollection implements Collection
{
}