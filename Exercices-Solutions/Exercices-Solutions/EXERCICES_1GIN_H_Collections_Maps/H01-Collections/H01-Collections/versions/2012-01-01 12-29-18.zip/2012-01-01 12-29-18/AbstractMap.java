public abstract class AbstractMap implements Map
{
}