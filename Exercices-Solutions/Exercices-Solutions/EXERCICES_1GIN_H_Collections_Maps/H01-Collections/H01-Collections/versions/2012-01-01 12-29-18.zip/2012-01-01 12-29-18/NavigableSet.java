public interface NavigableSet extends SortedSet
{
}