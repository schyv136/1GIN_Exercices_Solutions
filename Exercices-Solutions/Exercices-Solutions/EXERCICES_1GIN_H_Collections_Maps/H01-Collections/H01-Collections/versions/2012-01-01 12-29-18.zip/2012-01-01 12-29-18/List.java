public interface List extends Collection
{
}