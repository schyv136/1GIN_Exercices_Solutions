public interface Set extends Collection,Iterable
{
}