import java.awt.Color;

public class Triangle extends Shape
{
    private final double side1;
    private final double side2;
    private final double side3;

    public Triangle(double x, double y, Color color, double side1, double side2, double side3)
    {
        super(x, y, color);
        // inégalité triangulaire : sinon Héron donnerait NaN
        if (side1 + side2 <= side3 || side1 + side3 <= side2 || side2 + side3 <= side1)
            throw new IllegalArgumentException("Invalid triangle: " + side1 + ", " + side2 + ", " + side3);
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }

    public double getSide1() { return side1; }
    public double getSide2() { return side2; }
    public double getSide3() { return side3; }

    @Override
    public double getPerimeter() { return side1 + side2 + side3; }

    @Override
    public double getSurface()
    {
        // formule de Héron
        double s = getPerimeter() / 2;   // demi-périmètre
        return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
    }

    @Override
    public String toString()
    {
        return "Triangle ; " + super.toString() + " ; Sides=" + side1 + ", " + side2 + ", " + side3;
    }
}
