import java.awt.Color;

/**
 * Figure abstraite : position (point supérieur gauche) et couleur,
 * fixées lors de la construction.
 * L'ordre (compareTo) est hérité de l'interface Computable.
 */
public abstract class Shape implements Computable
{
    private final double x;
    private final double y;
    private final Color  color;

    public Shape(double x, double y, Color color)
    {
        this.x = x;
        this.y = y;
        this.color = color;
    }

    public double getX()     { return x;     }
    public double getY()     { return y;     }
    public Color  getColor() { return color; }

    @Override
    public String toString()
    {
        return "Surface=" + String.format("%.2f", getSurface())
             + " ; Perimeter=" + String.format("%.2f", getPerimeter())
             + " ; Point(" + x + "," + y + ") ; Color: " + color;
    }
}
