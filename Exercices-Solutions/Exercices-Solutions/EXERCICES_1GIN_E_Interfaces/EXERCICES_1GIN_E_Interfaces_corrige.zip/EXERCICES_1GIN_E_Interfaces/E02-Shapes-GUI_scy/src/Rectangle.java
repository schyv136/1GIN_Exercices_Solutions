import java.awt.Color;

public class Rectangle extends Shape
{
    private final double width;
    private final double height;

    public Rectangle(double x, double y, Color color, double width, double height)
    {
        super(x, y, color);
        this.width  = width;
        this.height = height;
    }

    public double getWidth()  { return width;  }
    public double getHeight() { return height; }

    @Override
    public double getPerimeter() { return 2 * (width + height); }

    @Override
    public double getSurface()   { return width * height; }

    @Override
    public String toString()
    {
        return "Rectangle ; " + super.toString() + " ; Width=" + width + " ; Height=" + height;
    }
}
