import javax.swing.JButton;

/**
 * Bouton Swing qui est aussi un Computable.
 * Surface et périmètre sont calculés à partir des dimensions ACTUELLES
 * du composant (getWidth()/getHeight() hérités de JComponent).
 * Remarque : un composant qui vient d'être créé a une taille 0x0 tant qu'on
 * ne lui a pas donné de dimensions -> on utilise setBounds dans le constructeur.
 */
public class MyButton extends JButton implements Computable
{
    public MyButton(int x, int y, int width, int height, String text)
    {
        super(text);
        setBounds(x, y, width, height);
    }

    @Override
    public double getSurface()   { return (double) getWidth() * getHeight(); }

    @Override
    public double getPerimeter() { return 2.0 * (getWidth() + getHeight()); }

    // JButton.toString() renvoie un très long texte technique -> on le remplace
    @Override
    public String toString()
    {
        return "MyButton ; Surface=" + String.format("%.2f", getSurface())
             + " ; Perimeter=" + String.format("%.2f", getPerimeter())
             + " ; Point(" + getX() + "," + getY() + ")"
             + " ; Width=" + getWidth() + " ; Height=" + getHeight()
             + " ; Text='" + getText() + "'";
    }
}
