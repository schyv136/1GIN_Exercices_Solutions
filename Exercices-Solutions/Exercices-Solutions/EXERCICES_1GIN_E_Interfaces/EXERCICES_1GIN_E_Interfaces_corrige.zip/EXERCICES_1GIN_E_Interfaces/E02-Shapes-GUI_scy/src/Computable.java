/**
 * Tout objet "calculable" possède une surface et un périmètre.
 *
 * Computable étend Comparable<Computable> : deux Computable quelconques
 * (une figure, un bouton, un champ texte...) peuvent être comparés
 * d'après leur surface. Collections.sort / Arrays.sort utilisent cet
 * ordre interne.
 *
 * La méthode compareTo est définie ici une seule fois comme méthode
 * "default" (Java 8+). Alternative sans méthode default : déclarer
 * seulement "extends Comparable<Computable>" et implémenter compareTo
 * dans Shape, MyButton et MyTextField.
 */
public interface Computable extends Comparable<Computable>
{
    public abstract double getSurface();
    public abstract double getPerimeter();

    @Override
    public default int compareTo(Computable other)
    {
        // Double.compare évite les problèmes d'arrondi d'un (int)(a-b)
        return Double.compare(getSurface(), other.getSurface());
    }
}
