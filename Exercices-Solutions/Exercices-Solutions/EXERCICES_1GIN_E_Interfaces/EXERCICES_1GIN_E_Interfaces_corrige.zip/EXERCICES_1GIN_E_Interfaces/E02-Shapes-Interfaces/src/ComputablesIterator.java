import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Itérateur fait "maison" pour Computables (version array).
 */
public class ComputablesIterator implements Iterator<Computable>
{
    private final Computables computables;    // la liste à parcourir
    private int     current       = 0;        // position du PROCHAIN élément
    private boolean removeAllowed = false;    // remove() seulement après next()

    public ComputablesIterator(Computables computables)
    {
        this.computables = computables;
    }

    /** Reste-t-il des éléments ? */
    @Override
    public boolean hasNext()
    {
        return current < computables.size();
    }

    /** Renvoie l'élément suivant et avance d'une position. */
    @Override
    public Computable next()
    {
        if (!hasNext())
            throw new NoSuchElementException("ERROR: no more elements");
        removeAllowed = true;
        Computable c = computables.get(current);
        current++;
        return c;
    }

    /** Supprime le dernier élément renvoyé par next() (optionnel). */
    @Override
    public void remove()
    {
        if (!removeAllowed)
            throw new IllegalStateException("ERROR: each call to remove() must be preceded by a call to next()");
        current--;                   // le dernier élément renvoyé est en current-1
        computables.remove(current); // les suivants sont décalés -> current pointe à nouveau sur le prochain
        removeAllowed = false;
    }
}
