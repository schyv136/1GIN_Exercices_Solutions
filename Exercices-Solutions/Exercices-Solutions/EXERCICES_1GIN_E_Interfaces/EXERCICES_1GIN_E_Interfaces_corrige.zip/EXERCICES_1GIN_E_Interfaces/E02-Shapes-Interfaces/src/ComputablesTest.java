import java.awt.Color;
import java.util.Iterator;

/**
 * Test de Computables (version 2 : array) avec des figures,
 * des MyButton et des MyTextField.
 */
public class ComputablesTest
{
    public static void main(String[] args)
    {
        Computables computables = new Computables();

        computables.add(new Triangle (100, 100, Color.RED,  40, 50, 30));
        computables.add(new Rectangle(200, 200, Color.BLUE, 50, 60));
        computables.add(new Circle   (300, 300, Color.PINK, 10));
        computables.add(new Square   (400, 400, Color.CYAN, 25));
        computables.add(new MyButton   (10, 10, 120, 30, "OK"));
        computables.add(new MyButton   (10, 50,  20, 20, "X"));
        computables.add(new MyTextField(10, 80, 200, 25, "Name"));
        computables.add(new MyTextField(10, 120, 15, 15, "?"));

        System.out.println("=== Unsorted (for each) ===");
        for (Computable c : computables)
            System.out.println(c);

        computables.sort();

        System.out.println("\n=== Sorted by surface (for each) ===");
        for (Computable c : computables)
            System.out.printf("%-12s surface=%10.2f  perimeter=%8.2f%n",
                              c.getClass().getSimpleName(), c.getSurface(), c.getPerimeter());

        System.out.println("\n=== Explicit Iterator ===");
        Iterator<Computable> it = computables.iterator();
        while (it.hasNext())
            System.out.println(it.next());

        System.out.println("\n=== Iterator.remove(): remove all elements with surface < 1000 ===");
        it = computables.iterator();
        while (it.hasNext())
            if (it.next().getSurface() < 1000)
                it.remove();
        System.out.println(computables);
    }
}
