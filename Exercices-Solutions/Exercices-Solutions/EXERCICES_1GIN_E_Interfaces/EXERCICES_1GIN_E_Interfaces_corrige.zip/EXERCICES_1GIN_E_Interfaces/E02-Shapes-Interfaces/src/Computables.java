import java.util.Arrays;
import java.util.Iterator;

/**
 * Computables - Version 2 : tableau statique (array) arComputables.
 *
 * Les éléments occupent toujours les positions 0 .. size-1 du tableau.
 * L'attribut size est la dimension effective (nombre d'éléments utilisés),
 * arComputables.length est la capacité maximale.
 */
public class Computables implements Iterable<Computable>
{
    public static final int MAX_SIZE = 100;

    private Computable[] arComputables = new Computable[MAX_SIZE];
    private int size = 0;

    public void add(Computable computable)
    {
        if (size == arComputables.length)
            throw new IllegalStateException("ERROR: Computables is full (" + arComputables.length + " elements)");
        arComputables[size] = computable;
        size++;
    }

    public Computable get(int i)
    {
        if (i < 0 || i >= size)
            throw new IndexOutOfBoundsException("ERROR: index " + i + " - Computables only contains " + size + " elements");
        return arComputables[i];
    }

    public int size()
    {
        return size;
    }

    /** Supprime l'élément à la position i (les suivants sont décalés vers la gauche). */
    public void remove(int i)
    {
        if (i < 0 || i >= size)
            throw new IndexOutOfBoundsException("ERROR: index " + i + " - Computables only contains " + size + " elements");
        for (int j = i; j < size - 1; j++)
            arComputables[j] = arComputables[j + 1];
        size--;
        arComputables[size] = null;   // libérer la dernière référence
    }

    /** Copie des éléments utilisés seulement (sans les cases null). */
    public Object[] toArray()
    {
        return Arrays.copyOf(arComputables, size);
    }

    /**
     * Tri d'après l'ordre interne (Comparable -> surface).
     * Attention : il ne faut trier que la partie utilisée [0, size[ ,
     * sinon Arrays.sort rencontrerait des null -> NullPointerException.
     */
    public void sort()
    {
        Arrays.sort(arComputables, 0, size);
    }

    /** Renvoie notre propre itérateur (voir ComputablesIterator). */
    @Override
    public Iterator<Computable> iterator()
    {
        return new ComputablesIterator(this);
    }

    @Override
    public String toString()
    {
        String res = "size=" + size + "\n";
        for (Computable c : this)
            res = res + c + "\n";
        return res;
    }
}
