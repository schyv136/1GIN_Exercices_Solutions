
import java.io.IOException;
import java.util.Scanner;

/*
 */

/**
 *
 * @author fred
 */
public class Test {
       //************************************ MAIN ***************************************

    //test this class
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the number of fractions : ");
        int n = input.nextInt();

        FractionList fl = new FractionList();
        fl.addRandomFractions(n, -100, 100);

        /* File operations (série précédente) :
        try {
            fl.saveToTextFile("fractions.txt");
            fl.loadFromTextFile("fractions.txt");
        } catch (IOException ex) {
            System.err.println("FILE : " + ex);
        }
        */

        //========== E.1.1 + E.1.2 : sort (Comparable) et itérateur ==========
        System.out.println("\n-> Original list :");
        fl.printAll();
        fl.sort();
        System.out.println("-> Sorted list (Collections.sort) :");
        fl.iterate();

        //========== E.1.3 : clone de Fraction ==========
        System.out.println("\n-> Test Cloneable Fraction:");
        Fraction f1 = new Fraction(10, 6);
        Fraction f2 = f1.clone();
        System.out.println("original f1 = " + f1 + "   clone f2 = " + f2);
        f1.add(new Fraction(2, 5));     // modifier l'original
        System.out.println("after f1.add(2/5):  f1 = " + f1 + "   f2 = " + f2);
        f1 = null;                      // "supprimer" l'original
        System.out.println("after f1 = null:    f1 = " + f1 + "   f2 = " + f2);
        // => le clone est un objet indépendant : il ne change pas.

        //========== E.1.4 : clone de FractionList ==========
        FractionList shallow = fl.shallowClone();   // seulement la méthode héritée
        FractionList deep    = fl.clone();          // copie profonde

        // modifications de l'ORIGINAL après le clonage :
        fl.add(new Fraction(100, 1));               // ajouter un élément
        fl.get(0).setFraction(999, 1);              // modifier une fraction existante

        System.out.println("\n-> Original after modification (added 100, first set to 999) :");
        fl.printAll();
        System.out.println("-> Shallow clone (super.clone() only) :");
        shallow.printAll();
        // => même ArrayList : contient aussi 100 et 999 !
        System.out.println("-> Deep clone :");
        deep.printAll();
        // => propre ArrayList et propres fractions : inchangé.
    }

}
