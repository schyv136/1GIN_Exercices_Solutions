# Série E : Interfaces – Réponses aux questions

## Exercice E.1 : FractionList

**E.1.1 – Tri avec `Collections.sort`**
`Fraction` implémente `Comparable<Fraction>` ; `compareTo` compare les valeurs décimales avec
`Double.compare(getDecimal(), other.getDecimal())`. La méthode `sort()` de `FractionList` appelle
simplement `Collections.sort(alFractions)`.
Remarque : `(int)(getDecimal() - other.getDecimal())` serait faux (0.3 → 0 → « égal »).

**E.1.2 – Itérateur**
La boucle `for (Fraction f : alFractions)` utilise implicitement l'itérateur de l'`ArrayList`
(`printAll`, `saveTo…File`, `clone`). La méthode `iterate()` montre l'emploi explicite
(`iterator()`, `hasNext()`, `next()`).

**E.1.3 – `clone()` de Fraction**
- ajouter `implements Cloneable` (sinon `Object.clone()` lève `CloneNotSupportedException`) ;
- redéfinir `clone()` comme **public** (elle est `protected` dans `Object`) et appeler `super.clone()`.

*Que se passe-t-il dans la copie si on modifie / supprime l'original ?* Rien. Le clone est un
nouvel objet ; `super.clone()` a copié les attributs `numerator` et `denominator`. Comme ce sont des
types primitifs (`int`), la copie est complète et indépendante. Mettre `f1 = null` supprime seulement
la référence vers l'original ; le clone continue d'exister.

**E.1.4 – `clone()` de FractionList**
*Que se passe-t-il dans la copie si on n'utilise que la méthode héritée ?*
`super.clone()` fait une **copie superficielle** (*shallow copy*) : elle copie l'attribut
`alFractions`, c.-à-d. la **référence** vers l'`ArrayList`. Original et copie partagent donc la même
liste : un élément ajouté à l'original apparaît aussi dans la copie, et une fraction modifiée dans
l'original est aussi modifiée dans la copie (voir `shallowClone()` dans `Test`).

*Comment y remédier ?* Par une **copie profonde** (*deep copy*) :
1. `super.clone()` pour créer la copie ;
2. donner à la copie sa **propre** `ArrayList` ;
3. y ajouter des **clones** des fractions.

Remarque : `new ArrayList<>(alFractions)` ou `alFractions.clone()` ne suffisent pas. Ils créent une
nouvelle liste, mais celle-ci contient les mêmes objets `Fraction` : un ajout dans l'original n'est
plus visible dans la copie, mais la modification d'une fraction l'est toujours.

Autres solutions courantes : un constructeur de copie `FractionList(FractionList other)`, ou la
sérialisation.

## Exercice E.3 : Listeners

Lorsqu'on crée l'événement *actionPerformed* du bouton, NetBeans ajoute dans la partie cachée
`initComponents()` (bloc grisé « Generated Code », non modifiable, décrit aussi dans le fichier
`.form`) :

```java
jButton1.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        jButton1ActionPerformed(evt);
    }
});
```

et dans la partie visible une méthode vide `private void jButton1ActionPerformed(ActionEvent evt)`.

Explication :
- `ActionListener` est une **interface** avec une seule méthode : `actionPerformed(ActionEvent e)`.
- `new ActionListener() { … }` crée un objet d'une **classe anonyme** qui implémente cette interface.
- `addActionListener(…)` **enregistre** cet objet auprès du bouton. Le bouton garde une liste
  de ses « auditeurs » (*listeners*).
- Quand on clique, le bouton appelle `actionPerformed` de chaque listener enregistré. Il ne connaît
  de ces objets que leur interface `ActionListener` : c'est justement à ça que sert l'interface
  (principe de l'observateur / *Observer*).
- Ici, `actionPerformed` ne fait que déléguer à `jButton1ActionPerformed(evt)`, la méthode où l'on
  écrit son propre code.

(Dans NetBeans, l'option *Listener Generation Style* permet aussi d'autres styles, p.ex. une seule
classe interne ou `MainFrame implements ActionListener`.)

## Exercice E.4 : MiniDraw

**Pourquoi une interface `Drawable` n'est-elle pas utile ?**
Toutes les figures dérivent déjà de la même classe (abstraite) `Figure`, qui déclare `draw(Graphics g)`.
`FigureList` gère une liste de `Figure` et appelle `draw` de façon **polymorphe**. La super-classe
commune joue donc déjà le rôle de l'interface ; `Drawable` n'apporterait rien.

**Quand serait-elle utile ?**
Dès qu'on veut dessiner dans la même liste des objets qui **ne dérivent pas** de `Figure`, en
particulier des objets qui ont déjà une autre super-classe (Java ne permet qu'un seul `extends`).
Exemples : un texte/légende (`Label`), une image (`Picture`), une grille d'arrière-plan, ou un
composant dérivé d'une classe Swing (cf. `MyButton extends JButton implements Computable` dans E.2).
Chacun pourrait `implements Drawable` sans hériter de `Figure`.

**Transformations dans `FigureList`**
- `ArrayList<Figure>` → `ArrayList<Drawable>` (et éventuellement renommer en `DrawableList`) ;
- `add(Figure f)` → `add(Drawable d)` ; `get` renvoie un `Drawable` ;
- la méthode de dessin parcourt `for (Drawable d : alDrawables) d.draw(g);` ;
- `Figure implements Drawable` (les sous-classes en héritent) ;
- les méthodes qui utilisent des fonctionnalités propres à `Figure` (sélection, déplacement,
  couleur, surface…) ne sont plus disponibles directement. Il faut soit les ajouter à l'interface,
  soit tester `instanceof Figure` et faire un cast.
