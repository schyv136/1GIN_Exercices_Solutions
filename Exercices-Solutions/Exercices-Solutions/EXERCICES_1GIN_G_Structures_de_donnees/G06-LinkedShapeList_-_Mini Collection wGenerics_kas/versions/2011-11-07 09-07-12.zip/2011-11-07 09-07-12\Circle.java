import java.awt.Color;

public class Circle extends Shape
{

	protected double radius;

	public Circle(double x, double y, Color color, double radius)
	{
		super(x,y,color);
		this.radius=radius;
	}


	public double getRadius()
	{
		return radius;
	}
}