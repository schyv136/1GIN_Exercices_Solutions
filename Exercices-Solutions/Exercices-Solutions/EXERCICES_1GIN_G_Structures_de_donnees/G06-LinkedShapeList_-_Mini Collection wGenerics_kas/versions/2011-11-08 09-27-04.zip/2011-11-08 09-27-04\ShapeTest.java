import java.awt.Color;
public class ShapeTest
{

    public static void main(String[] args) 
    {
        ShapeList shapeList = new ShapeList();
        Triangle  t = new Triangle (100,100, java.awt.Color.red , 40,50,30); 
        Rectangle r = new Rectangle(200,200, java.awt.Color.blue, 50,60); 
        Circle    c = new Circle   (300,300, java.awt.Color.pink, 110);
        Square    s = new Square   (400,400, java.awt.Color.cyan, 120);
        shapeList.add(t);
        shapeList.add(r);
        shapeList.add(s);
        shapeList.add(c);
        System.out.println(shapeList);
        System.out.println(shapeList.get(1).getSurface());
        System.out.println(shapeList.get(3).getPerimeter());
        System.out.println(shapeList.get(5).getSurface());
    }
}