package simpleLinkedList;

/**
 *
 * @author Fred Faber
 */
public class SimpleLinkedList<E> implements java.lang.Iterable<E>
{
/*
boolean add(Object)     Permet d'ajouter un élément à la liste.
void clear()            Vide la liste en supprimant tous les éléments.
boolean contains(Object) Teste si la liste contient un élément donné.
Object get(int)         Retourne l'élément à la position indiquée dans le paramètre.
int indexOf(Object)     Retourne la position de l'élément indiqué dans le paramètre 
                        ou -1 si l'élément ne se trouve pas dans la liste.
Object remove(int)      Supprime l'élément à la position indiquée dans le paramètre.
                        (Les éléments qui suivent l'élément supprimé avancent
                        automatiquement d'une position.)
Object set(int, Object) Remplace l'élément à la position spécifiée par celui passé en
                        tant que paramètre.
int size()              Retourne la taille de la liste, donc le nombre d'éléments y
                        contenus.
Object[] toArray()      Transforme la liste en un « Array ». Cette méthode est
                        uniquement nécessaire pour la visualisation des éléments à
                        l'aide d'un composant « JList » (voir chapitre suivant).
     */
    
    private Node<E> first=null;
    
    /* ========================================================================================== */


	//Send back List's own Iterator
        @Override
	public java.util.Iterator<E> iterator() {
  		return new SimpleLinkedListIterator<E>(first);
 	}


    /* ========================================================================================== */


    /**
     * Permet d'ajouter un élément à la liste.
     * @param o     l'objet à ajouter
     * @return      true (toujours)
     */
    public boolean add(E o) 
    {
        Node<E> el = new Node(o);
        if (first==null)
        {
            first=el;
        }    
        else
        {
            Node<E> p=first;
            while (p.getNext()!=null) p=p.getNext();
            p.setNext(el);
        }
        return true; //List has changed!
    }
    /** Vide la liste en supprimant tous les éléments.
     */
    public void clear()
    {
        first=null;
        // everything else is done by the garbage collector...
    }
    
    /**
     * Teste si la liste contient un objet donné.
     * @return true si l'objet se trouve dans la liste
     */
    public boolean contains(E o)
    {
        boolean result = false;
        Node<E> p=first;
        while (!result && p!=null) 
            if (p.getObject()==o) result = true;
            else p = p.getNext();
        return result;
    }
    /**
     * Retourne l'élément à la position indiquée dans le paramètre.
     * @param n l'indice de l'élément
     * @return l'objet à la position i ou null si on trouvé
     */
    public E get(int n)        
    {
       E result = null;
       Node<E> p=first;
       int i=0;
       while (p!=null && i!=n)
       {
           p = p.getNext();
           i++;
       }
       if (i==n) result = p.getObject();
       return result;
    }
    
    /**
     *    Retourne la position de l'élément indiqué dans le paramètre 
                        ou -1 si l'élément ne se trouve pas dans la liste.
     * @param o l'objet à rechercher
     * @return  la position de l'objet ou -1
     */
    public int indexOf(E o)  
    {
        int result = -1;
        Node<E> p=first;
        int i=-1;
        while (result==-1 && p!=null) 
        {
            i++;
            if (p.getObject()==o) result = i;
            else p = p.getNext();
        }
        return result;
    }
    
    
    /**
     * Supprime l'élément à la position indiquée dans le paramètre.
           (Les éléments qui suivent l'élément supprimé avancent
               automatiquement d'une position.)
     * @param i
     * @return the element that was removed from the list
     */
    public E remove(int n)
    {
       E result = null;
       if (n==0 && first!=null) 
       {
           result=first.getObject();
           first=first.getNext();
       }
       else
       {
           Node<E> p = first;
           int i=0;
           while (p.getNext()!=null && i!=n-1)
           {
               p = p.getNext();
               i++;
           } 
           //maintenant p pointe sur le prédécesseur de l'objet à supprimer
           //si p.getNext existe... :
           if (i==n-1)
           {
               result = p.getNext().getObject();
               p.setNext(p.getNext().getNext());
           }               
       }
       return result;
   }

    
   /**
    *  Retourne la taille de la liste, donc le nombre d'éléments y contenus. 
    * @return la taille de la liste
    */
    public int size()  
    {
       Node<E> p=first;
       int result=0;
       while (p!=null) 
       {
           p = p.getNext();
           result++;
       }
       return result;
    }
 
    
    /**
     *  Remplace l'élément à la position spécifiée par celui passé en
                        tant que paramètre.
     * @return l'objet ou null
     */
    public E set(int n, E o)
    {
       E result = null;
       Node<E> p=first;
       int i=0;
       while (p!=null && i!=n)
       {
           p = p.getNext();
           i++;
       }
       if (i==n)
       {
           result = p.getObject();
           p.setObject(o);
       }
       return result;
    }

    /**
     * Transforme la liste en un « Array ». Cette méthode est
     * uniquement nécessaire pour la visualisation des éléments à
     * l'aide d'un composant « JList » (voir chapitre suivant).
     */ 
     public Object[] toArray()
     {
         Object[] result=new Object[size()];
         Node<E> p=first;
         for(int i=0 ; i<size() ; i++)
         {
             result[i]=p.getObject();
             p=p.getNext();
         }
         return result;
     }
     
}
