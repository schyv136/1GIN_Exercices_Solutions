package simpleLinkedList;

/**
 * Node of of linked list defined in LinkedList
 * @author FabFr297
 */
public class Node<E> {
        private E  o   = null;
        private Node next= null;
        
        public Node (E o)
        {
            this.o = o;
            next=null;
        }
        
        public Node<E> getNext()
        {
            return next;
        }

        public void setNext(Node<E> e)
        {
            next = e;
        }

        public E getObject()
        {
            return o;
        }

        public void setObject(E o)
        {
            this.o = o;
        }

    }