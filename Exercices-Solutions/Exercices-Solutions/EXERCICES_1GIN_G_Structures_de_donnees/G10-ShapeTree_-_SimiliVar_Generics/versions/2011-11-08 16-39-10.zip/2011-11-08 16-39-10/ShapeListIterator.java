public class ShapeListIterator implements java.util.Iterator<Shape>
{
	protected Shape[] shapes;
	protected int current = 0;  //-> used in implementation of Iterator

 	public ShapeListIterator(Shape[] shapes) {  
  		this.shapes =  shapes;  
  		current = 0;  
 	}  

	/**
	 * Return the next item in the list (and move on to the next item)
	 * @return the current Item
	 */
	public Shape next()
	{
  		if (!hasNext()) 
  			throw new java.util.NoSuchElementException("ERROR: No such Element in list");
		else 
			return shapes[current++];
	}

	/**
	 * Are there more items in the list?
	 * @return true <=> yes there are more elements
	 */
	public boolean hasNext()
	{
		return true;//current < count;
	}

	/**
	 * Delete the last item returned by next(). - optional -
	 */
	public void remove()
	{
		/*
		if (current>=count)
			throw new java.util.NoSuchElementException("ERROR: No more element in the list");
		else 
			{
				for (int i=current ; i<count-1 ; i++)
					shapes[i] = shapes[i+1];
				count--;
			}
		*/
	}


}