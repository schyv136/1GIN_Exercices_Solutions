import java.util.NoSuchElementException;
import java.util.Iterator;

public class ShapeList implements java.lang.Iterable<Shape>
{
	protected static final int MAXCOUNT=100;
	protected Shape[] shapes = new Shape[MAXCOUNT];
	protected int count   = 0;

	public int getCount() {return count;} 

	public Shape get(int i) 
	{ 
		if (i>=count) 
		     throw new java.lang.ArrayIndexOutOfBoundsException(
		     	"ERROR: Index out of Bounds - Array only contains "+count+" shapes!");
		return shapes[i]; 
	}
	
	/* ajout à la fin
	public int add(Shape shape) 
	{
		if (count<MAXCOUNT) 
		{
			shapes[count] = shape;
			count++;
		}
		else throw new java.lang.ArrayIndexOutOfBoundsException("ERROR: No space left in Shape Array");
		return count-1; 
	}
	*/

	/* ajout trié */
	public int add(Shape shape) 
	{
		int insertPos=count;
		if (count<MAXCOUNT) 
		{
			while(insertPos>0 && shapes[insertPos-1].compareTo(shape) == 1) 
			{
				shapes[insertPos]=shapes[insertPos-1];
				insertPos--;
			}
			shapes[insertPos] = shape;
			count++;
		}
		else throw new java.lang.ArrayIndexOutOfBoundsException("ERROR: No space left in Shape Array");
		return insertPos; 
	}


	public String toString()
	{
		String res="count="+count+"\n";
		for (int i=0 ; i<count ; i++) 
			res = res + shapes[i].toString()+"\n";
		return res;		
	}

   /** ========================================================================================== */
	
	
	@Override  
 	public Iterator<Shape> iterator() {  
  		return new ShapeListIterator(shapes);  
 	}  
 	
}