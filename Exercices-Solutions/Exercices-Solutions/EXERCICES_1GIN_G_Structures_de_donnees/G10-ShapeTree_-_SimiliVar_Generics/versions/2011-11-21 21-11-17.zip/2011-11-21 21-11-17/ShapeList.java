import java.util.Iterator;
import java.util.ArrayList;
//imports for file saving
import java.io.*;
import java.io.IOException;


/**
 * ShapeList : ArrayList of Shapes 
 * Shapes are always sorted by their surface.
 * ShapeList is Iterable (<=> it can return an Iterator to run through the array) 
 */
public class ShapeList implements java.lang.Iterable<Shape>
{
	private ArrayList<Shape> shapes = new ArrayList<Shape>();

	public int getCount() 
	{
		return shapes.size();
	} 

	public Shape get(int i) 
	{ 
		return shapes.get(i); 
	}
	
	/* ajout non trié */
	/*
	public int add(Shape shape) 
	{
		shapes.add(shape);
		return getCount(); 
	}
	*/
	
	/* ajout trié */
	public int add(Shape shape) 
	{
		int insertPos=getCount();
		shapes.add(null); //a new (empty) reference MUST be created!!!
		while(insertPos>0 && get(insertPos-1).compareTo(shape) == 1) 
			{
				shapes.set(insertPos,get(insertPos-1));
				insertPos--;
			}
		shapes.set(insertPos, shape);
		return insertPos; 
	}

	/**
	 * effacer tout
	 */
	public void clear()
	{
		shapes.clear();
	}

	public String toString()
	{
		String res="count="+getCount()+"\n";
		int i=0;
		while ( i<getCount() )
		{
			res = res + get(i).toString()+"\n";
			i++;
		}			
		return res;		
	}

	/* ========================================================================================== */

	
	//Send back ArrayList's own Iterator (no need to define a new one...)
	@Override  
 	public Iterator<Shape> iterator() {  
  		return shapes.iterator();  
 	} 

 	 
	/* ========================================================================================== */
	

	public void saveToFile(String fileName)
	{
		try 
		{
			FileOutputStream   f_out   = new FileOutputStream(fileName);
			ObjectOutputStream obj_out = new ObjectOutputStream (f_out);
			obj_out.writeObject(shapes);
			obj_out.close();
		}
		catch (Exception e) 
		{ System.out.println("Error saving file : "+fileName +"\n"+e.getMessage()); }
	}
    
    
	public void loadFromFile(String fileName)
	{
		try 
		{
			shapes.clear();    //supprimer d'abord la bibliothèque actuelle
			FileInputStream   f_in = new FileInputStream(fileName);
			ObjectInputStream obj_in = new ObjectInputStream (f_in);
			shapes = (ArrayList)obj_in.readObject();
			obj_in.close();
		}
		catch (Exception e)
		{ System.out.println("Error reading file : "+fileName +"\n"+e.getMessage()); }
	}

}