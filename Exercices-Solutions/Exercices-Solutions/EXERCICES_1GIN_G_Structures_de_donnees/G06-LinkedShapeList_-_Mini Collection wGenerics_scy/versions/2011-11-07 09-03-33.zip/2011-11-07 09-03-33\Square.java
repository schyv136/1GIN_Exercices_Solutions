public class Square extends Shape
{

	protected double side;

	public double getSide()
	{
		return side;
	}
}