public class Triangle extends Shape
{

	protected double side1;

	protected double side2;

	protected double side3;

	public double getSide1()
	{
		return side1;
	}

	public double getSide2()
	{
		return side2;
	}

	public double getSide3()
	{
		return side3;
	}
}