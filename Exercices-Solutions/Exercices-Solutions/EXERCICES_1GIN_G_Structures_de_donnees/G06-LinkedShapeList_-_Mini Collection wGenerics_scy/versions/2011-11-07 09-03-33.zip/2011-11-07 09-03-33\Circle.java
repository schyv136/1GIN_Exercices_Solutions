public class Circle extends Shape
{

	protected double radius;

	public double getRadius()
	{
		return radius;
	}
}