public class Rectangle extends Shape
{

	protected double length;

	protected boolean width;

	public double getLength()
	{
		return length;
	}

	public boolean isWidth()
	{
		return width;
	}
}