/**
 * Write a description of class "bla" here.
 * 
 * @author     fred
 * @version    14/11/2011 01:35:36
 */
public class bla
{

    /**
	 * The main entry point for executing this program.
	 */
    public static void main(String[] args) 
    {
        
    }
}