import java.awt.Color;
import java.io.Serializable;

public class Square extends Shape implements Serializable
{
	private double side;
	
	public Square(double x, double y, Color color, double side)
	{
		super(x,y,color);
		this.side=side;
	}

	public double getSide()	{return side;	}
	
	public String toString()
	{
		return "Square ; " + super.toString() + " ; " +
			  "Side="+side;
	}
	
	public double getPerimeter()
	{
		return 4 * side;
	}
	
	public double getSurface()
	{
		return side * side;
	}	

}