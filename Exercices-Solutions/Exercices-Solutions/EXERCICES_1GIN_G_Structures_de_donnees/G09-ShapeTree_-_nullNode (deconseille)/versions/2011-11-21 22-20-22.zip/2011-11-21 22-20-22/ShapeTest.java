//import java.util.Iterator;

public class ShapeTest
{

    public static void main(String[] args) 
    {
        Triangle  t = new Triangle (100,100, java.awt.Color.red , 40,50,30); 
        Rectangle r = new Rectangle(200,200, java.awt.Color.blue, 50,60); 
        Circle    c = new Circle   (300,300, java.awt.Color.pink, 10);
        Square    s = new Square   (400,400, java.awt.Color.cyan, 25);
        ShapeList shapeList = new ShapeList();
        shapeList.add(t);
        shapeList.add(r);
        shapeList.add(s);
        shapeList.add(c);
        System.out.println(shapeList);

	System.out.println("\n/* Use for each (implicit) Iterator */");
	for (Shape sh : shapeList) 
		System.out.println("Surface of shape ="+sh.getSurface()); 

	System.out.println("saving...");
	shapeList.saveToFile("allShapes.shp");	
	System.out.println("clearing...");
	shapeList.clear();
     System.out.println(shapeList);

	System.out.println("loading...");
	shapeList.loadFromFile("allShapes.shp");
	System.out.println("contents :");
     System.out.println(shapeList);

    }
}