public class ShapeListIterator implements java.util.Iterator<Shape>
{
	protected Shape[] shapes;
	protected int current = 0;  //-> used in implementation of Iterator

 	public ShapeListIterator(Shape[] shapes) {  
  		this.shapes =  shapes;  
  		current = 0;  
 	}  

	/**
	 * Return the next item in the list (and move on to the next item)
	 * traversing the whole list works only once... for each newly created iterator
	 * @return the current Item
	 */
	public Shape next()
	{
  		if (!hasNext()) 
  			throw new java.util.NoSuchElementException("ERROR: No such Element in list");
		else 
			return shapes[current++];
	}

	/**
	 * Are there more items in the list?
	 * @return true <=> yes there are more elements
	 */
	public boolean hasNext()
	{
		return shapes[current] != null;
	}

	/**
	 * Delete the last item returned by next() - optional -
	 */
	public void remove()
	{
		if (shapes[current]==null)
			throw new java.util.NoSuchElementException("ERROR: No more elements in the list");
		else 
			{
				int i=current;
				while ( i<shapes.length && shapes[i+1]!=null )
					{
						shapes[i] = shapes[i+1];
						i++;
					}					
				if (i<shapes.length) shapes[i]=null;
			}
	}


}