public class ShapeList 
{
	protected static final int MAXCOUNT=1000;
	protected Shape[] shapes = new Shape[MAXCOUNT];
	protected int count = 0;

	public int getCount() {return count;} 

	public Shape get(int i) { return shapes[i]; }
	public int add(Shape shape) 
	{
		if (count<MAXCOUNT) 
		{
			shapes[count] = shape;
			count++;
		}
		else throw new java.lang.ArrayIndexOutOfBoundsException("ERROR: No space left in Shape Array");
		
		return count-1; 
	}

	public String toString()
	{
		String res="count="+count+"\n";
		for (int i=0 ; i<count ; i++) 
			res = res + shapes[i].toString()+"\n";
		return res;		
	}
}