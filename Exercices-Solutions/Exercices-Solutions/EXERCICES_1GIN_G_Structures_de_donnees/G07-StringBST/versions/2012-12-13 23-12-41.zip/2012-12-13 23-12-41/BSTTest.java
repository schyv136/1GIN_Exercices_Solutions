/**
 *
 * @author fred
 */
import binarySearchTree.BST;
import shapes.Circle;
import shapes.Rectangle;
import shapes.Shape;
import shapes.Square;
import shapes.Triangle;
public class BSTTest {
    
    public static void main(String[] args) 
    {
        Triangle  t = new Triangle (100,100, java.awt.Color.red , 40,50,30); 
        Rectangle r = new Rectangle(200,200, java.awt.Color.blue, 50,60); 
        Circle    c = new Circle   (300,300, java.awt.Color.pink, 10);
        Square    s = new Square   (400,400, java.awt.Color.cyan, 25);
        
        BST bst = new BST();

        bst.add(t);
        bst.add(r);
        bst.add(s);
        bst.add(c);
        System.out.println(bst);

	System.out.println("\n/* Use for each (implicit) Iterator */");
	for (Object sh : bst)
		System.out.println("Surface of shape ="+((Shape)sh).getSurface());
        System.out.println("\n/* Use counting for loop */");
	for (int i=0 ; i<bst.size() ; i++)
                System.out.println("Surface of shape ="+bst.get(i));

        System.out.println("Triangle  is at position : "+bst.indexOf(t));
        System.out.println("Rectangle is at position : "+bst.indexOf(r));
        System.out.println("\n/************ remove triangle ************/");
	System.out.println("* Removed: "+bst.remove(t));
        for (Object sh : bst)
		System.out.println((Shape)sh);

        System.out.println("\n/************ remove pos 2 ************/");
	System.out.println("* Removed: "+bst.remove(2));
        for (Object sh : bst)
		System.out.println((Shape)sh);
        
        System.out.println("\n/************ remove pos 0 ************/");
	System.out.println("* Removed: "+bst.remove(0));
        for (Object sh : bst)
		System.out.println((Shape)sh);

        System.out.println("\n/************ remove pos 0 ************/");
	System.out.println("* Removed: "+bst.remove(0));
        for (Object sh : bst)
		System.out.println(sh);
        
        System.out.println("\n/************ remove pos 0 ************/");
	System.out.println("* Removed: "+bst.remove(0));
        for (Object sh : bst)
		System.out.println((Shape)sh);

    }    
}