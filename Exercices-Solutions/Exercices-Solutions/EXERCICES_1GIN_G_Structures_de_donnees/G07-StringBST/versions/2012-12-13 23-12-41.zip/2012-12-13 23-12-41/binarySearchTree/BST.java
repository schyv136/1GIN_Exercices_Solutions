package binarySearchTree;

/**
 * Binary Search Tree - ABR Arbre Binaire de Recherche
 * @author Fred Faber
 */

public class BST implements java.lang.Iterable
{
/* 
     * Comme il est impossible de passer des paramètres par référence, 
     * la racine de l'arbre ne peut pas être changée par une méthode.
     * Pour simuler le passage par référence, on utilise ici des méthodes 
     * qui obtiennent un noeud (la racine de l'arbre à considérer) comme 
     * paramètre ET LE RETOURNENT COMME RESULTAT.
     * La méthode appelante DOIT AFFECTER LE RESULTAT AU NOEUD (RACINE).
 */
    
    private Node root=null;
    
    /* ========================================================================================== */


	//Send back List's own Iterator
        @Override
	public java.util.Iterator iterator() {
  		return new BSTIterator(root);
 	}


    /* ========================================================================================== */

    public  BST() {
        root = null;
    }
     
    
   /**
     * True ssi l'arbre est vide
     * @return      true si l'arbre est vide
     */
     public boolean isEmpty() {
        return root==null;
    }
    
    /**
     * Recursively add an object to the tree (order : + )
     * @param n  the current n of the tree (seen recursively)
     * @param data     the object to add
      * @return la nouvelle valeur du noeud (nouveau pointeur)
     */
    private Node addRecursion(Node n, Comparable data) {
        if (n == null)   //tree was empty
            n = new Node(data);
        else     
        {             
            if (data.compareTo(n.getData())<0)  //add to the left..
                n.setLeft (addRecursion(n.getLeft(),data));
            else                                   //add to the right..
                n.setRight(addRecursion(n.getRight(),data));
        }   
        return n;
    }

    /**
     * Permet d'ajouter un élément à l'arbre.
     * utilise la méthode récursive addRecursion
     * @param data     l'objet à ajouter
     * @return      true (toujours)
     */
    public boolean add(Comparable data)
    {        
        root = addRecursion(root, data);
        return true; //List has changed!
    }

    /** Vide l'arbre en supprimant tous les éléments.
     */
    public void clear()
    {
        root = null;
        // everything else is done by the garbage collector...
    }


    private boolean containsRecursion(Node n, Comparable data) {
        if (n == null)
            return false;
        else if (n.getData().compareTo(data)==0)
            return true;
        else if (n.getData().compareTo(data) > 0)
            return containsRecursion(n.getLeft(),  data);
        else
            return containsRecursion(n.getRight(), data);
    }

    /**
     * Teste si l'arbre contient un objet donné.
     * utilise la méthode récursive containsRecursion
     * @return true si l'objet se trouve dans l'arbre
     */
    public boolean contains(Comparable data)
    {
        return containsRecursion(root, data);
    }

    /**
     * Retourne l'élément à la position indiquée dans le paramètre.
     * @param n l'indice de l'élément
     * @return l'objet à la position i ou null si non trouvé
     */
    public Comparable get(int i)
    {
       if (i<size())
           return (Comparable)toArray()[i];
       else 
           return null;
    }
    
    /**
     * Retourne la position de l'élément indiqué dans le paramètre 
     *                   ou -1 si l'élément ne se trouve pas dans la liste.
     * (Méthode pas vraiment efficace pour un arbre)
     * @param data l'objet à rechercher
     * @return  la position de l'objet ou -1
     */
    public int indexOf(Comparable data)
    {
        Object[] ar = toArray();

        int result = -1;
        int i=-1;
        while (result==-1 && i<ar.length-1)
        {
            i++;
            if (ar[i].equals(data)) result = i;
        }
        return result;
    }
    
    
    /**   profite de la méthode remove(Object) - voir ci-dessous
     * Supprime l'élément à la position indiquée dans le paramètre.
           (Les éléments qui suivent l'élément supprimé avancent
               automatiquement d'une position.)
     * @param i
     * @return the element that was removed from the list
     */
    public Comparable remove(int i)
    {
        Comparable data = get(i);
        if (remove(data))
            return data;
        else 
            return null;
    }
    
    
    private boolean isLeaf(Node n)
    {
            return n!=null && n.getLeft()==null && n.getRight()==null;
    }
    
    /**
     * Removes element e from a tree recursively starting at n
     * @param n root of the current tree
     * @param e object to be removed
     * @return (changed) node n
     */
    
    private boolean elementRemoved; //used to be compatible with Collection 
    private Node removeRecursion(Node n, Comparable data)
    {
        if (n==null) //Tree empty or not found
            elementRemoved=false; //nothing to do ...
        else if (n.getData().compareTo(data) > 0) //Go left
            n.setLeft ( removeRecursion(n.getLeft (), data) );
        else if (n.getData().compareTo(data) < 0) //Go right
            n.setRight( removeRecursion(n.getRight(), data) );
        else //if (n.getData()==data)
            {  //object found -> remove it
                if (n.getLeft()==null && n.getRight()==null) //only 1 node
                    n=null;
                else if (n.getLeft()==null)   //subtree only on the right side           
                    n = n.getRight(); 
                else if (n.getRight()==null)  //subtree only on the left side         
                    n = n.getLeft();                     
                else //subtree at both sides 
                {
                    Node right = n.getRight(); //memorize top of right subtree
                    n = n.getLeft();  //link in the left subtree
                    //get right end node of the left subtree (i.data. null pointer on the right)
                    Node REnd=n;
                    while (REnd.getRight()!=null) REnd = REnd.getRight();
                    //add right subtree here
                    REnd.setRight(right);
                }  
                elementRemoved=true;                
            }        
        return n; //return node (maybe changed)
    }
    
    /**   
     * Supprime l'élément à la position indiquée dans le paramètre.
           (Les éléments qui suivent l'élément supprimé avancent
               automatiquement d'une position.)
     * @param e l'objet à supprimer
     * @return true if remove successful (uses private elementRemoved
     */
    public boolean remove(Comparable data)
    {
        elementRemoved=false;                
        root = removeRecursion(root, data); 
        return elementRemoved;                
    }
    
    
    private int sizeRecursion(Node n) {
        if (n == null) return 0;
        else return 1 + sizeRecursion(n.getLeft()) + sizeRecursion(n.getRight());
    }
    
    /**
    * Retourne la taille de l'arbre, donc le nombre d'éléments y contenus. 
    * utilise la méth récursive  sizeRecursion
    * @return la taille de la liste
    */
    public int size()  
    {
       return sizeRecursion(root);
    }
 
    
    /**
     *  Remplace l'élément à la position spécifiée par celui passé en
     *                  tant que paramètre. IMPOSSIBLE/INUTILE pour un ABR!
     * @return l'objet ou null
     */
    public Comparable set(int i, Comparable data)
    {
       throw new java.lang.UnsupportedOperationException
               ("Error: 'Set' is an unsupported operation in a Search Tree");
       //return null;
    }

    
   
    private int infixArray(Node n, Object[] ar, int result) {
      if (n != null) {  
        result = infixArray(n.getLeft() , ar, result);
        ar[result++]=n.getData();
        result = infixArray(n.getRight(), ar, result);
      }
      return result;
    }
    
    
    /**
     * Transforme l'arbre en un « Array ». Cette méthode est
     * uniquement nécessaire pour la visualisation des éléments à
     * l'aide d'un composant « JList » .
     * utilise la méthode récursive infixArray
     * IMPOSSIBLE de retourner un array Comparable[] -> 'ERR: generic array creation'
     * Ne peut pas être évité simplement
     */ 
    public Object[] toArray()
    {
         Object[] result=new Object[size()];
        
         infixArray(root, result, 0);
         return result;
     }

   /**
     * Transforme l'arbre en un « Array ». Cette méthode est
     * uniquement nécessaire pour la visualisation des éléments à
     * l'aide d'un composant « JList » .
     * utilise l'itérateur à travers for
     * IMPOSSIBLE de retourner un array Comparable[] -> 'ERR: generic array creation'
     * Ne peut pas être évité simplement
     */ 
    public Object[] toArray_()
    {
         Object[] result=new Object[size()];
        
         int i=0;
         for (Object data : this) {
             result[i] = data;
             i++;
         }
              
         //infixArray(root,result,0);
         return result;
     }


 

    public int depthRecursion(Node n) {
        if (n != null) return 0;
        else  return 1 + Math.max( depthRecursion(n.getLeft()),
                                   depthRecursion(n.getRight()));
    }
    /**
     * Retourne la profondeur de l'arbre
     * @return
     */
    private int getDepth()  {
        return depthRecursion(root);
    }
}