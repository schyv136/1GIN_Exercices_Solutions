import java.awt.Color;

public abstract class Shape implements Computable
{

	protected double x;
	protected double y;
	protected Color color;

	public double getX()	{ return x;	}
	public double getY()	{ return y;	}
	public Color getColor()	{ return color;}

	public Shape(double x, double y, Color color)
	{
		this.x=x;
		this.y=y;
		this.color = color;
	}

	public String toString()
	{
		return "Point ("+x+","+y+") ; Color: "+getColor();
	}
}