import java.awt.Color;

public class Shape
{
	protected double x;
	protected double y;
	protected Color color;

	public double getX()	{ return x;	}
	public double getY()	{ return y;	}
	public Color getColor()	{ return color;}

	public String toString()
	{
		return "Point ("+x+","+y+") ; Color: "+getColor();
	}
}